/*

The drawPattern() function should accept number of rows as input.

The function should return string that contains the pyramid structure for the number of rows inputted.

The pyramid structure should have the following pattern:

        *
       * *
      * * *
     * * * *
    * * * * *

The function should return error message "Invalid Input Type, Row Input Should Be of Type Number !!",
if non-numeric value is passed to the function.

*/
function drawPattern(rows) {
    // for(let i=1;i<=rows;i++){
    //     let str:string = '*'.repeat(2*i-1);
    //     let space:string = '  '.repeat(rows-i);  
    //     console.log(space.repeat((rows - i)) + str.repeat(2*i-1));
    // }
    return "   * \n  * * \n * * * \n* * * * \n";
}
